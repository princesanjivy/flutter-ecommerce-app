import 'package:flutter/material.dart';

const String appName = "E - COM APP";

Color primaryColor = const Color(0xFFEA5D5D);
